export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api',
  imageBaseUrl: 'http://localhost:8080/api/uploads/images',
};
