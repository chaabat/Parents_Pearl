export const environment = {
  production: true,
  apiUrl: 'https://your-production-api.com/api',
  imageBaseUrl: 'https://your-production-api.com/api/uploads/images'
};
