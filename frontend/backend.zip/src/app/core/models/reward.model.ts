export interface Reward {
  id: number;
  name: string;
  description: string;
  pointCost: number;
  parentId: number;
}
