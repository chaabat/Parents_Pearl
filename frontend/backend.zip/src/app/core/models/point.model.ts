export interface Point {
  id: number;
  childId: number;
  points: number;
  reason: string;
  createdAt: Date;
}
