package com.parentPearl.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
 
import java.util.Date;

@Data
public abstract class BaseUserRequest {
    @NotBlank(message = "Name is required")
    private String name;
    
    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;
    
    @NotBlank(message = "Password is required")
    private String password;
    
    private String picture;
    
    @NotNull(message = "Date of birth is required")
    private Date dateOfBirth;

    private boolean deleted;
} 