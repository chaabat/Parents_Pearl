package com.parentPearl.exception;

public class TokenException extends RuntimeException {
    public TokenException(String message) {
        super(message);
    }
} 