package com.parentPearl.model.enums;

public enum Role {
    ADMIN, PARENT, CHILD
}
