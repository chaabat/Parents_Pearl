package com.parentPearl.model.enums;

public enum TaskStatus {
     PENDING, COMPLETED ,FAILED
}
