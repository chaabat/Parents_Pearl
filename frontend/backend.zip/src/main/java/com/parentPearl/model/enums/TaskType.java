package com.parentPearl.model.enums;

public enum TaskType {
    MAZE, TRUE_FALSE, HOMEWORK, QUIZ, READING, VIDEO
}
