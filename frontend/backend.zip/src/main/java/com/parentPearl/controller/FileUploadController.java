package com.parentPearl.controller;

import com.parentPearl.dto.response.FileUploadResponse;
import com.parentPearl.service.interfaces.FileStorageService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
@RequestMapping("/api/upload")
public class FileUploadController {

    @Autowired
    private FileStorageService fileStorageService;

    @PostMapping("/images")
    public ResponseEntity<FileUploadResponse> uploadFile(@RequestParam("file") MultipartFile file) {
        String fileName = fileStorageService.storeFile(file);
        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                                 .path("/download/")
                                 .path(fileName)
                                 .toUriString();

        return ResponseEntity.status(HttpStatus.OK).body(new FileUploadResponse(fileName, fileDownloadUri, file.getContentType(), file.getSize()));
    }
} 